<!DOCTYPE html>
<html>
<head>
	<title>Show page</title>
</head>
<body>
  
    <h1>{{$tacks->body}}</h1>


</body>
</html>