<!DOCTYPE html>
<html>
<head>
    <title>My 1st page</title>
</head>
<body>
   
   <ul>
       
       @foreach( $tacks as $tack )

           <li>

           <a href="/tacks/{{ $tack->id }}"> {{ $tack->body }} </a>

           </li>

       @endforeach

   </ul>

</body>
</html>