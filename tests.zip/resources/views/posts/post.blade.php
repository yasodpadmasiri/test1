
         <table class="table">
		    <thead>
		      <tr>
		        <th>Name</th>
		        <th>Residence Address</th>
		        <th>Correspond Address</th>
		        <th>Telephone Number</th>
		        <th>Mobile Number</th>
		        <th>NIC</th>
		        <th>Email</th>
		      </tr>
		    </thead>
		    <tbody>
		      <tr>
		        <td>{{ $post->name }}</td>
		        <td>{{ $post->r_address  }}</td>
		        <td>{{ $post->c_address }}</td>
		        <td>{{ $post->tel }}</td>
		        <td>{{ $post->mob  }}</td>
		        <td>{{ $post->nic }}</td>
		        <td>{{ $post->email }}</td>
		      </tr>
		    </tbody>
		  </table>

