@extends('layouts.master')


    @section('content')

        <div class="col-md-12">

        

            @foreach($posts as $post)


        	      @include('posts.post')


             @endforeach 



         </div>


@endsection