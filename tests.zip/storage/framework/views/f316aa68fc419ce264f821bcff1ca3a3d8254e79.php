<!DOCTYPE html>
<html>
<head>
	<title>Show page</title>
</head>
<body>
  
    <h1><?php echo e($tacks->body); ?></h1>


</body>
</html>