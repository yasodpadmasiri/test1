
         <table class="table">
		    <thead>
		      <tr>
		        <th>Name</th>
		        <th>Residence Address</th>
		        <th>Correspond Address</th>
		        <th>Telephone Number</th>
		        <th>Mobile Number</th>
		        <th>NIC</th>
		        <th>Email</th>
		      </tr>
		    </thead>
		    <tbody>
		      <tr>
		        <td><?php echo e($post->name); ?></td>
		        <td><?php echo e($post->r_address); ?></td>
		        <td><?php echo e($post->c_address); ?></td>
		        <td><?php echo e($post->tel); ?></td>
		        <td><?php echo e($post->mob); ?></td>
		        <td><?php echo e($post->nic); ?></td>
		        <td><?php echo e($post->email); ?></td>
		      </tr>
		    </tbody>
		  </table>

