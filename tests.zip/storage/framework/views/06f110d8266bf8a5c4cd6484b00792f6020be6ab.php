<?php $__env->startSection('content'); ?>

       
				 <h1>Form</h1>

             <div class="container">
				 <form method="POST" action="/posts">

				     <?php echo e(csrf_field()); ?>


				    <div class="form-group">
				      <label for="name">Name:</label>
				      <input type="name" class="form-control" id="name" name="name">
				    </div>
				    <div class="form-group">
				      <label for="r_address">Residence Address:</label>
				      <input type="r_address" class="form-control" id="r_address" name="r_address">
				    </div>
				    <div class="form-group">
				      <label for="c_address">Correspond Address:</label>
				      <input type="c_address" class="form-control" id="c_address"  name="c_address">
				    </div>
				    <div class="form-group">
				      <label for="tel">Telephone Number:</label>
				      <input type="tel" class="form-control" id="tel"  name="tel">
				    </div>
				    <div class="form-group">
				      <label for="mob">Mobile Number:</label>
				      <input type="mob" class="form-control" id="mob"  name="mob">
				    </div>
				    <div class="form-group">
				      <label for="nic">NIC:</label>
				      <input type="nic" class="form-control" id="nic"  name="nic">
				    </div>
				    <div class="form-group">
				      <label for="email">Email:</label>
				      <input type="email" class="form-control" id="email"  name="email">
				    </div>
				    <button type="submit" class="btn btn-primary">Submit</button>
				 </form>
			</div>

       

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>