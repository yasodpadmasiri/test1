<!DOCTYPE html>
<html>
<head>
    <title>My 1st page</title>
</head>
<body>
   
   <ul>
       
       <?php $__currentLoopData = $tacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

           <li> <?php echo e($tack->body); ?> </li>

       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   </ul>

</body>
</html>