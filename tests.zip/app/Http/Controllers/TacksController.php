<?php

namespace App\Http\Controllers;

use App\tack;

class TacksController extends Controller
{
    public function index(){

           $tacks = tack::all();

           return view ('tacks.index', compact('tacks'));

    }

    public function show(tack $tacks){


          return view ('tacks.show', compact('tacks'));


    }
}
