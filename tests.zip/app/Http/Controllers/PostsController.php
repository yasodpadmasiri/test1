<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Post;

class PostsController extends Controller
{
    public function index(){

    	

        return view('posts.index');

    }

    public function show(){

    	$posts=Post::all();

        return view('posts.show', compact('posts'));

    }
    public function store(){


       Post::create(request(['name','r_address','c_address','tel','mob','nic','email']));


       return redirect('/');

    }
}
