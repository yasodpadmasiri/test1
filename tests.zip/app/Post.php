<?php

namespace App;


class Post extends Model
{
   
}
