<?php



// Route::get('/tacks','TacksController@index');

// Route::get('/tacks/{tacks}','TacksController@show');

Route::get('/', 'PostsController@index');

Route::get('/posts/{past}','PostsController@show');

Route::post('/posts','PostsController@store');

