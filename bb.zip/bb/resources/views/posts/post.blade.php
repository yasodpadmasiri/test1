
       
		    <tbody>
		      <tr>
		        <td>{{ $post->name }}</td>
		        <td>{{ $post->r_address  }}</td>
		        <td>{{ $post->c_address }}</td>
		        <td>{{ $post->tel }}</td>
		        <td>{{ $post->mob  }}</td>
		        <td>{{ $post->nic }}</td>
		        <td>{{ $post->email }}</td>
		      </tr>
		    </tbody>
		 

