@extends('layouts.master')


    @section('content')

        <div class="col-md-12">

            <table class="table">
		    <thead>
		      <tr>
		        <th>Name</th>
		        <th>Residence Address</th>
		        <th>Correspond Address</th>
		        <th>Telephone Number</th>
		        <th>Mobile Number</th>
		        <th>NIC</th>
		        <th>Email</th>
		      </tr>
		    </thead>

            @foreach($posts as $post)


        	      @include('posts.post')


             @endforeach 

           </table>

         </div>


@endsection