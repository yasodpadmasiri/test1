    <?php $__env->startSection('content'); ?>

        <div class="col-md-12">

            <table class="table">
		    <thead>
		      <tr>
		        <th>Name</th>
		        <th>Residence Address</th>
		        <th>Correspond Address</th>
		        <th>Telephone Number</th>
		        <th>Mobile Number</th>
		        <th>NIC</th>
		        <th>Email</th>
		      </tr>
		    </thead>

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        	      <?php echo $__env->make('posts.post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

           </table>

         </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>